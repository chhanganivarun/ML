#ifndef metadata
#define metadata

#define attrno 64
// 64
// 7

struct {
	char filename[101];
	int datasize;
}md={"../optical_data/optdigits.tra",3823};
//"../optical_data/optdigits.tra",3823
// "../seeds_dataset.txt",210


#endif
